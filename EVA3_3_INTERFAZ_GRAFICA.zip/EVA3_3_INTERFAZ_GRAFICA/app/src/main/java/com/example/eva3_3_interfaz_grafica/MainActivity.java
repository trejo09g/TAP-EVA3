package com.example.eva3_3_interfaz_grafica;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;



public class MainActivity extends AppCompatActivity
implements RadioGroup.OnCheckedChangeListener{






    RadioGroup rdEstadoCivil;


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //View es una clase, son las base de todos los componetes
        //grafica en Android, Es una area rectangular donde se dibuja algo
        rdEstadoCivil = findViewById(R.id.RadioGroup1);
        //Vincular eventos : al igual que en java --->Listerns
        rdEstadoCivil.setOnCheckedChangeListener(this);

    }


    @Override
    protected void onPostResume() {
        super.onPostResume();
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {

    }
}
